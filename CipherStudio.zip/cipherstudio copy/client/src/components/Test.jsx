export default function Test() {
  return (
    <div style={{ padding: 20 }}>
      <h1>SMOKE: App Runs</h1>
    </div>
  );
}
